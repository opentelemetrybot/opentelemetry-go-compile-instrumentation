// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package server

import (
	"context"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/propagation"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/sdk/trace/tracetest"
	semconv "go.opentelemetry.io/otel/semconv/v1.37.0"
	"go.opentelemetry.io/otel/trace"

	"go.opentelemetry.io/otelc/pkg/hook"
	"go.opentelemetry.io/otelc/pkg/hook/hooktest"
)

func setupTestTracer(t *testing.T) (*tracetest.SpanRecorder, *sdktrace.TracerProvider) {
	t.Helper()
	sr := tracetest.NewSpanRecorder()
	tp := sdktrace.NewTracerProvider(sdktrace.WithSpanProcessor(sr))
	otel.SetTracerProvider(tp)
	otel.SetTextMapPropagator(propagation.TraceContext{})
	t.Cleanup(func() { _ = tp.Shutdown(context.Background()) })
	return sr, tp
}

func TestBeforeServeHTTP(t *testing.T) {
	tests := []struct {
		name            string
		setupEnv        func(t *testing.T)
		setupRequest    func() *http.Request
		expectSpan      bool
		validateSpan    func(*testing.T, trace.Span)
		validateWriter  func(*testing.T, http.ResponseWriter)
		validateContext func(*testing.T, *http.Request)
	}{
		{
			name: "basic request creates span",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				return httptest.NewRequest("GET", "http://example.com/path", nil)
			},
			expectSpan: true,
			validateSpan: func(t *testing.T, span trace.Span) {
				assert.NotNil(t, span)
			},
			validateWriter: func(t *testing.T, w http.ResponseWriter) {
				_, ok := w.(*writerWrapper)
				assert.True(t, ok, "writer should be wrapped")
			},
		},
		{
			name: "instrumentation disabled",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				return httptest.NewRequest("GET", "http://example.com/path", nil)
			},
			expectSpan: false,
		},
		{
			name: "POST request",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				return httptest.NewRequest("POST", "http://example.com/api/data", nil)
			},
			expectSpan: true,
		},
		{
			name: "request with trace context propagation",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				req := httptest.NewRequest("GET", "http://example.com/path", nil)
				// Add traceparent header to simulate incoming trace
				req.Header.Set("traceparent", "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0bb902b7-01")
				return req
			},
			expectSpan: true,
			validateContext: func(t *testing.T, req *http.Request) {
				// Context should have extracted trace
				spanCtx := trace.SpanContextFromContext(req.Context())
				assert.True(t, spanCtx.IsValid())
			},
		},
		{
			name: "request with route pattern (Go 1.22+)",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				req := httptest.NewRequest("GET", "http://example.com/users/123", nil)
				req.SetPathValue("id", "123")
				return req
			},
			expectSpan: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Reset initialization for each test by creating a new once
			initOnce = *new(sync.Once)

			tt.setupEnv(t)
			sr, _ := setupTestTracer(t)

			req := tt.setupRequest()
			w := httptest.NewRecorder()
			mockCtx := hooktest.NewMockHookContext()

			BeforeServeHTTP(mockCtx, nil, w, req)

			if tt.expectSpan {
				spans := sr.Ended()
				// Span should not be ended yet in Before hook
				assert.Equal(t, 0, len(spans), "span should not be ended in Before hook")

				// Check that data was stored
				data, ok := mockCtx.GetData().(map[string]interface{})
				require.True(t, ok, "data should be stored")
				require.NotNil(t, data, "data should not be nil")

				span, ok := data["span"].(trace.Span)
				require.True(t, ok, "span should be in data")
				require.NotNil(t, span, "span should not be nil")

				if tt.validateSpan != nil {
					tt.validateSpan(t, span)
				}

				// Check that ResponseWriter was wrapped
				wrappedWriter, ok := mockCtx.GetParam(1).(http.ResponseWriter)
				require.True(t, ok, "param 1 should be ResponseWriter")
				require.NotNil(t, wrappedWriter, "wrapped writer should not be nil")

				if tt.validateWriter != nil {
					tt.validateWriter(t, wrappedWriter)
				}

				if tt.validateContext != nil {
					// Get the updated request with the new context
					updatedReq, ok := mockCtx.GetParam(2).(*http.Request)
					require.True(t, ok, "param 2 should be updated request")
					tt.validateContext(t, updatedReq)
				}
			} else {
				// No span should be created
				data := mockCtx.GetData()
				assert.Nil(t, data, "no data should be stored when instrumentation disabled")
			}
		})
	}
}

func TestAfterServeHTTP(t *testing.T) {
	tests := []struct {
		name         string
		setupEnv     func(t *testing.T)
		setupContext func(*sdktrace.TracerProvider) hook.HookContext
		statusCode   int
		validateSpan func(*testing.T, []sdktrace.ReadOnlySpan)
	}{
		{
			name: "successful 200 response",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				ctx, span := testTracer.Start(
					context.Background(),
					"GET /path",
					trace.WithSpanKind(trace.SpanKindServer),
				)

				mockCtx := hooktest.NewMockHookContext()
				wrapper := &writerWrapper{
					ResponseWriter: httptest.NewRecorder(),
					statusCode:     200,
				}
				mockCtx.SetParam(1, wrapper)
				mockCtx.SetData(map[string]interface{}{
					"ctx":  ctx,
					"span": span,
				})
				return mockCtx
			},
			statusCode: 200,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				assert.Equal(t, codes.Unset, span.Status().Code)
			},
		},
		{
			name: "404 not found",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				ctx, span := testTracer.Start(
					context.Background(),
					"GET /notfound",
					trace.WithSpanKind(trace.SpanKindServer),
				)

				mockCtx := hooktest.NewMockHookContext()
				wrapper := &writerWrapper{
					ResponseWriter: httptest.NewRecorder(),
					statusCode:     404,
				}
				mockCtx.SetParam(1, wrapper)
				mockCtx.SetData(map[string]interface{}{
					"ctx":  ctx,
					"span": span,
				})
				return mockCtx
			},
			statusCode: 404,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				// 404 is not an error from OTel perspective for servers
				assert.Equal(t, codes.Unset, span.Status().Code)
			},
		},
		{
			name: "500 internal server error",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				ctx, span := testTracer.Start(
					context.Background(),
					"GET /error",
					trace.WithSpanKind(trace.SpanKindServer),
				)

				mockCtx := hooktest.NewMockHookContext()
				wrapper := &writerWrapper{
					ResponseWriter: httptest.NewRecorder(),
					statusCode:     500,
				}
				mockCtx.SetParam(1, wrapper)
				mockCtx.SetData(map[string]interface{}{
					"ctx":  ctx,
					"span": span,
				})
				return mockCtx
			},
			statusCode: 500,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				assert.Equal(t, codes.Error, span.Status().Code)
			},
		},
		{
			name: "no data in context",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				return hooktest.NewMockHookContext()
			},
			statusCode: 200,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				// No span should be ended
				assert.Equal(t, 0, len(spans))
			},
		},
		{
			name: "instrumentation disabled",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				ctx, span := testTracer.Start(
					context.Background(),
					"GET /path",
					trace.WithSpanKind(trace.SpanKindServer),
				)

				mockCtx := hooktest.NewMockHookContext()
				wrapper := &writerWrapper{
					ResponseWriter: httptest.NewRecorder(),
					statusCode:     200,
				}
				mockCtx.SetParam(1, wrapper)
				mockCtx.SetData(map[string]interface{}{
					"ctx":  ctx,
					"span": span,
				})
				return mockCtx
			},
			statusCode: 200,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				// The span should still be ended when instrumentation is disabled.
				assert.Equal(t, 1, len(spans))
			},
		},
		{
			name: "no wrapper in context",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				ctx, span := testTracer.Start(
					context.Background(),
					"GET /path",
					trace.WithSpanKind(trace.SpanKindServer),
				)

				mockCtx := hooktest.NewMockHookContext()
				// Don't set param 1, defaults to 200
				mockCtx.SetData(map[string]interface{}{
					"ctx":  ctx,
					"span": span,
				})
				return mockCtx
			},
			statusCode: 200,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				// Should still work with default 200
				span := spans[0]
				assert.Equal(t, codes.Unset, span.Status().Code)
			},
		},
		{
			name: "matched route renames span and sets http.route",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				ctx, span := testTracer.Start(
					context.Background(),
					"GET",
					trace.WithSpanKind(trace.SpanKindServer),
				)

				req := httptest.NewRequest("GET", "http://example.com/hello/world", nil)
				req.Pattern = "GET /hello/{name}"

				mockCtx := hooktest.NewMockHookContext()
				mockCtx.SetParam(1, &writerWrapper{ResponseWriter: httptest.NewRecorder(), statusCode: 200})
				mockCtx.SetParam(2, req)
				mockCtx.SetData(map[string]interface{}{"ctx": ctx, "span": span})
				return mockCtx
			},
			statusCode: 200,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				assert.Equal(t, "GET /hello/{name}", span.Name())
				assert.Contains(t, span.Attributes(), semconv.HTTPRoute("/hello/{name}"))
			},
		},
		{
			// gin and chi name the span themselves and leave r.Pattern empty.
			name: "unmatched route leaves span name alone",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				ctx, span := testTracer.Start(
					context.Background(),
					"GET /set/by/gin",
					trace.WithSpanKind(trace.SpanKindServer),
				)

				req := httptest.NewRequest("GET", "http://example.com/hello/world", nil)

				mockCtx := hooktest.NewMockHookContext()
				mockCtx.SetParam(1, &writerWrapper{ResponseWriter: httptest.NewRecorder(), statusCode: 200})
				mockCtx.SetParam(2, req)
				mockCtx.SetData(map[string]interface{}{"ctx": ctx, "span": span})
				return mockCtx
			},
			statusCode: 200,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				assert.Equal(t, "GET /set/by/gin", span.Name())
				for _, attr := range span.Attributes() {
					assert.NotEqual(t, semconv.HTTPRouteKey, attr.Key, "http.route must not be set")
				}
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Reset initialization for each test by creating a new once
			initOnce = *new(sync.Once)

			tt.setupEnv(t)
			sr, tp := setupTestTracer(t)

			mockCtx := tt.setupContext(tp)

			AfterServeHTTP(mockCtx)

			spans := sr.Ended()
			if tt.validateSpan != nil {
				tt.validateSpan(t, spans)
			}
		})
	}
}

func TestServerEnabler(t *testing.T) {
	tests := []struct {
		name     string
		setupEnv func(t *testing.T)
		expected bool
	}{
		{
			name: "enabled explicitly",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			expected: true,
		},
		{
			name: "disabled explicitly",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")
			},
			expected: false,
		},
		{
			name: "not in enabled list",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "grpc")
			},
			expected: false,
		},
		{
			name: "default enabled when no env set",
			setupEnv: func(t *testing.T) {
				// No environment variables set - should be enabled by default
			},
			expected: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.setupEnv(t)

			enabler := netHttpServerEnabler{}
			result := enabler.Enable()
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestWriterWrapper_IntegrationWithHandler(t *testing.T) {
	tests := []struct {
		name               string
		handler            http.HandlerFunc
		expectedStatusCode int
		expectedBody       string
	}{
		{
			name: "handler that sets status",
			handler: func(w http.ResponseWriter, r *http.Request) {
				w.WriteHeader(http.StatusCreated)
				w.Write([]byte("created"))
			},
			expectedStatusCode: http.StatusCreated,
			expectedBody:       "created",
		},
		{
			name: "handler that only writes",
			handler: func(w http.ResponseWriter, r *http.Request) {
				w.Write([]byte("ok"))
			},
			expectedStatusCode: http.StatusOK,
			expectedBody:       "ok",
		},
		{
			name: "handler that returns error",
			handler: func(w http.ResponseWriter, r *http.Request) {
				http.Error(w, "internal error", http.StatusInternalServerError)
			},
			expectedStatusCode: http.StatusInternalServerError,
			expectedBody:       "internal error\n",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rec := httptest.NewRecorder()
			wrapper := &writerWrapper{
				ResponseWriter: rec,
				statusCode:     http.StatusOK,
			}

			req := httptest.NewRequest("GET", "/test", nil)
			tt.handler(wrapper, req)

			assert.Equal(t, tt.expectedStatusCode, wrapper.statusCode)
			assert.Equal(t, tt.expectedBody, rec.Body.String())
		})
	}
}

func TestAfterServeHTTP_DisabledAfterStart_Regression(t *testing.T) {
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")

	initOnce = *new(sync.Once)
	sr, _ := setupTestTracer(t)

	req := httptest.NewRequest("GET", "/test", nil)
	w := httptest.NewRecorder()
	mockCtx := hooktest.NewMockHookContext()

	BeforeServeHTTP(mockCtx, nil, w, req)

	ended := sr.Ended()
	assert.Empty(t, ended, "span should not be ended before AfterServeHTTP")

	// Disable instrumentation while the request is in flight.
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")

	AfterServeHTTP(mockCtx)

	ended = sr.Ended()
	require.Len(t, ended, 1, "[] should have 1 item(s), but has 0")
	assert.Equal(t, "GET", ended[0].Name())
}
